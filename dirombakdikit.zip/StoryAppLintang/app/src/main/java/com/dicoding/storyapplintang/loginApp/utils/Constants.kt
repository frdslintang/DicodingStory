package com.dicoding.storyapplintang.loginApp.utils

object Constants {
    const val TOKEN = "token"
    const val SESSION = "session"
}