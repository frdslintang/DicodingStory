package com.dicoding.storyapplintang.loginApp.data.local.Room

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [Entity::class],
    version = 1,
    exportSchema = false
)
abstract class DatabaseStory : RoomDatabase() {
    abstract fun daoStory(): DaoStory

    companion object {
        @Volatile
        private var instance: DatabaseStory? = null

        fun getInstance(context: Context): DatabaseStory =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(context, DatabaseStory::class.java, "stories.db")
                    .build()
            }.also { instance = it }
    }
}